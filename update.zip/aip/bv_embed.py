# -*- coding: utf-8 -*-
"""Запуск AutoInformant Pro внутри окна BusVoice (Tk «-use»): python bv_embed.py <id_контейнера> <pid_BusVoice>."""
import os
import sys
import tkinter as tk

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)
WID = sys.argv[1] if len(sys.argv) > 1 else ""
PPID = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 0

if WID:
    _orig = tk.Tk.__init__

    def _init(self, *a, **k):
        if "use" not in k:
            k["use"] = WID
        _orig(self, *a, **k)
    tk.Tk.__init__ = _init

import AutoInformant as A  # noqa: E402


def alive(pid):
    if not pid:
        return True
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        return True


app = A.AutoInformantApp()


def watch():
    if not alive(PPID):
        try:
            app.on_close()
        except Exception:
            os._exit(0)
        return
    app.after(2000, watch)


app.after(2000, watch)
app.mainloop()
