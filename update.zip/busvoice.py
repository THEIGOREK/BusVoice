import os, runpy, sys
_d = os.path.dirname(os.path.abspath(sys.argv[0]))
_b = os.path.join(_d, "bin", "%d%d" % sys.version_info[:2])
def _fail(_t, _log=None):
    try:
        if _log:
            os.makedirs(os.path.join(_d, "data"), exist_ok=True)
            open(os.path.join(_d, "data", "crash.log"), "w", encoding="utf-8").write(_t)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, _t[-1500:], "BusVoice", 0x10)
    except Exception:
        print(_t)
    sys.exit(1)


if not os.path.isdir(_b):
    _fail("BusVoice: Python %d.%d не поддерживается.\nУстановите Python 3.12 или 3.13 (python.org) и запустите снова." % sys.version_info[:2])
for _n in ("lang", "tts", "hof", "scene", "flags", "informant_core", "openomsi_bridge", "auto_engine", "spatial_music"):      # остатки старых версий
    try:
        os.remove(os.path.join(_d, _n + ".py"))
    except OSError:
        pass
try:
    import shutil
    shutil.rmtree(os.path.join(_d, "__pycache__"), ignore_errors=True)
    for _r, _ds, _fs in os.walk(os.path.join(_d, "data", "_update")):     # копии старых исходников
        for _f in _fs:
            if _f.endswith(".py"):
                os.remove(os.path.join(_r, _f))
except Exception:
    pass
sys.path.insert(0, _b)
try:
    import bvfmt   # дополнительные звуковые форматы
except Exception:
    pass
try:
    import bvfix   # окно «Что нового» после обновления
except Exception:
    pass
try:
    runpy.run_module("bvmain", run_name="__main__")
except SystemExit:
    raise
except BaseException:
    import traceback
    _fail("BusVoice не запустился:\n" + traceback.format_exc() + "\n(лог: data\\crash.log)", True)
