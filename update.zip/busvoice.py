import os, runpy, sys
_d = os.path.dirname(os.path.abspath(sys.argv[0]))
_b = os.path.join(_d, "bin", "%d%d" % sys.version_info[:2])
def _fail(_t, _log=None):
    try:
        if _log:
            os.makedirs(os.path.join(_d, "data"), exist_ok=True)
            open(os.path.join(_d, "data", "crash.log"), "w", encoding="utf-8").write(_t)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, _t[-1500:], "BusVoice", 0x10)
    except Exception:
        print(_t)
    sys.exit(1)


def _heal(_tb):
    """Самовосстановление: если запуск сломан, тихо скачиваем свежую версию с GitHub и перезапускаемся."""
    try:
        import hashlib, io, json, subprocess, urllib.request, zipfile
        _hp = os.path.join(_d, "data", "heal.json")
        try:
            _st = json.load(open(_hp, encoding="utf-8"))
        except Exception:
            _st = {}
        _u = "https://raw.githubusercontent.com/THEIGOREK/BusVoice/main/update.json"
        _m = json.loads(urllib.request.urlopen(urllib.request.Request(_u, headers={"User-Agent": "BusVoice"}), timeout=15).read().decode("utf-8"))
        try:
            _cur = json.load(open(os.path.join(_d, "whatsnew.json"), encoding="utf-8")).get("version")
        except Exception:
            _cur = None
        _v = str(_m.get("version"))
        if _v == _cur or _st.get("tried") == _v or not str(_m.get("url", "")).startswith("https://"):
            return False
        os.makedirs(os.path.join(_d, "data"), exist_ok=True)
        json.dump({"tried": _v}, open(_hp, "w", encoding="utf-8"))      # одна попытка на версию — без зацикливания
        _z = urllib.request.urlopen(urllib.request.Request(_m["url"], headers={"User-Agent": "BusVoice"}), timeout=120).read()
        if hashlib.sha256(_z).hexdigest() != str(_m.get("sha256", "")).lower():
            return False
        with zipfile.ZipFile(io.BytesIO(_z)) as _zf:
            _base = os.path.abspath(_d) + os.sep
            for _i in _zf.infolist():
                _t = os.path.abspath(os.path.join(_d, _i.filename))
                if not _t.startswith(_base) or _i.filename.replace("\\", "/").startswith("data/"):
                    continue
                if _i.is_dir():
                    os.makedirs(_t, exist_ok=True)
                else:
                    os.makedirs(os.path.dirname(_t), exist_ok=True)
                    open(_t, "wb").write(_zf.read(_i))
        subprocess.Popen([sys.executable] + sys.argv, cwd=_d)
        return True
    except Exception:
        return False


if not os.path.isdir(_b):
    _fail("BusVoice: Python %d.%d не поддерживается.\nУстановите Python 3.12 или 3.13 (python.org) и запустите снова." % sys.version_info[:2])
for _n in ("lang", "tts", "hof", "scene", "flags", "informant_core", "openomsi_bridge", "auto_engine", "spatial_music"):      # остатки старых версий
    try:
        os.remove(os.path.join(_d, _n + ".py"))
    except OSError:
        pass
try:
    import shutil
    shutil.rmtree(os.path.join(_d, "__pycache__"), ignore_errors=True)
    for _r, _ds, _fs in os.walk(os.path.join(_d, "data", "_update")):     # копии старых исходников
        for _f in _fs:
            if _f.endswith(".py"):
                os.remove(os.path.join(_r, _f))
except Exception:
    pass
sys.path.insert(0, _b)
try:
    import bvfmt   # дополнительные звуковые форматы
except Exception:
    pass
try:
    import bvfix   # окно «Что нового» после обновления
except Exception:
    pass
try:
    runpy.run_module("bvmain", run_name="__main__")
except SystemExit:
    raise
except BaseException:
    import traceback
    _tb = traceback.format_exc()
    try:
        open(os.path.join(_d, "data", "crash.log"), "w", encoding="utf-8").write(_tb)
    except Exception:
        pass
    if _heal(_tb):
        sys.exit(0)
    _fail("BusVoice не запустился:\n" + traceback.format_exc() + "\n(лог: data\\crash.log)", True)
