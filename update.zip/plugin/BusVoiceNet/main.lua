-- BusVoice Net v1 - openOMSI LAN companion for BusVoice.
-- Lets players of one LAN session hear each other's stop announcements and (link/radio) music
-- from the other player's bus position. Audio itself is never sent over the network:
-- only short control messages travel through omsi.lan.send; every game builds the sound itself.
-- Plain Lua plugin, independent from AutoInformantPro.

local PORT = 47822
local OUT_FILE = "net_out.json"
local CMD_FILE = "net_cmd.json"
local LAN_PREFIX = "bv1;"

local cfg = {
    share_announce = true, share_music = true,
    hear_announce = true, hear_music = true,
    volume = 100, range_out = 4,
}

local function send_udp(t)
    local ok, enc = pcall(omsi.json.encode, t)
    if ok and type(enc) == "string" and #enc < 7000 then pcall(omsi.send, PORT, enc) end
end

local function read_json(path)
    local ok, content = pcall(omsi.plugin.read, path)
    if not ok or type(content) ~= "string" or content == "" then return nil end
    local ok2, v = pcall(omsi.json.decode, content)
    if ok2 and type(v) == "table" then return v end
    return nil
end

local function read_text(path)
    local ok, content = pcall(omsi.plugin.read, path)
    if ok and type(content) == "string" then return content end
    return nil
end

local ok_s, saved = pcall(omsi.plugin.settings, {
    { key = "share_announce", type = "bool", label = "Share my stop announcements with other players", default = true },
    { key = "share_music", type = "bool", label = "Share my music / radio (links only) with other players", default = true },
    { key = "hear_announce", type = "bool", label = "Hear other players' stop announcements", default = true },
    { key = "hear_music", type = "bool", label = "Hear other players' music / radio", default = true },
    { key = "volume", type = "number", label = "Volume of other players (%)", default = 100, min = 0, max = 200, step = 5 },
    { key = "range_out", type = "number", label = "Outside the bus: distance heard at full volume (m)", default = 4, min = 1, max = 30, step = 1 },
}, "BusVoice Net")
if ok_s and type(saved) == "table" then
    for k, v in pairs(saved) do cfg[k] = v end
end

local players = {}      -- id -> player table (position)
local outbox = {}       -- messages waiting for omsi.lan.send
local last_out_n = nil
local last_cmd_n = nil
local ann = {}          -- player id -> { q = {files}, cur = sound id }
local mus = {}          -- player id -> { gen, idx, dur, cur, prev, t }
local last_hb = -100

local function refresh_players()
    local ok, list = pcall(omsi.lan.players)
    local t = {}
    if ok and type(list) == "table" then
        for _, p in ipairs(list) do
            if type(p) == "table" and p.id ~= nil then t[tostring(p.id)] = p end
        end
    end
    players = t
end

-- 3D: heard only while you are in the sender's bus.
--   inside  = camera within INSIDE_NEAR m of the bus, or in a cab/bus and within INSIDE_FAR m
--   outside = a very quiet sound at the bus that fades to nothing within OUT_FADE m of the doorway
local INSIDE_NEAR = 6       -- m: always "inside"
local INSIDE_FAR = 20       -- m: "inside" when the game says the camera is in a vehicle
local OUT_FADE = 5          -- m: outside, audible only this far beyond INSIDE_NEAR, quietly

local function cam_pos()
    local ok, c = pcall(omsi.camera.get)
    if ok and type(c) == "table" and type(c.x) == "number" and type(c.y) == "number" then return c end
    return nil
end

-- returns opts, inside, dist   (opts = nil: nothing should be heard)
local function source_opts(from, vol)
    local p = players[tostring(from)]
    if not p or type(p.x) ~= "number" or type(p.y) ~= "number" then return nil, false, 999 end
    local base = (tonumber(vol) or 1) * (tonumber(cfg.volume) or 100) / 100
    local c = cam_pos()
    if not c then return nil, false, 999 end
    local pz = (type(p.z) == "number" and p.z or 0) + 1.5
    local dx, dy = c.x - p.x, c.y - p.y
    local dz = (type(c.z) == "number" and type(p.z) == "number") and (c.z - p.z) or 0
    local d = math.sqrt(dx * dx + dy * dy + dz * dz * 0.25)
    local incab = false
    local ok, ic = pcall(omsi.camera.in_cab)
    if ok and ic == true then incab = true end
    if c.in_cab == true then incab = true end
    local inside = d <= INSIDE_NEAR or (incab and d <= INSIDE_FAR)
    if inside then
        return { x = c.x, y = c.y, z = c.z or pz, range = 8, volume = base }, true, d
    end
    local edge = d - INSIDE_NEAR
    local k = 1 - edge / OUT_FADE
    if k <= 0 then return nil, false, d end
    return { x = p.x, y = p.y, z = pz, range = 2, volume = base * 0.25 * k }, false, d
end

local function stop_sound(id)
    if id then pcall(omsi.audio.stop, id) end
end

local function stop_player(from)
    local a = ann[from]
    if a then stop_sound(a.cur); ann[from] = nil end
    local m = mus[from]
    if m then stop_sound(m.cur); stop_sound(m.prev); mus[from] = nil end
end

local function stop_all()
    for from in pairs(ann) do stop_player(from) end
    for from in pairs(mus) do stop_player(from) end
end

local function heartbeat()
    local active = false
    local me = nil
    local ok, a = pcall(omsi.lan.active)
    if ok and a == true then active = true end
    local ok2, id = pcall(omsi.lan.me)
    if ok2 then me = id end
    local mpath = nil
    local okm, mi = pcall(omsi.map.info)
    if okm and type(mi) == "table" and type(mi.path) == "string" then mpath = mi.path end
    send_udp({ t = "hb", lan = active, me = me, cfg = cfg, map = mpath })
end

-- ------------------------------------------------------------------ outgoing (this player -> others)
local function poll_out()
    local v = read_json(OUT_FILE)
    if not v or type(v.items) ~= "table" then return end
    local top = tonumber(v.n) or 0
    if last_out_n == nil then last_out_n = top; return end   -- do not replay what was queued before the plugin loaded
    for _, it in ipairs(v.items) do
        local n = tonumber(it.n) or 0
        if n > last_out_n and type(it.m) == "string" then
            if it.m:sub(1, 4) == LAN_PREFIX then
                table.insert(outbox, 1, it.m)            -- commands (announcements, music state) go before audio data
            elseif #outbox < 40 then
                outbox[#outbox + 1] = it.m
            end
        end
    end
    if top > last_out_n then last_out_n = top end
end

local function pump_outbox()
    if #outbox == 0 then return end
    local ok, active = pcall(omsi.lan.active)
    if not ok or active ~= true then outbox = {}; return end
    local m = table.remove(outbox, 1)
    pcall(omsi.lan.send, 0, m)
end

-- ------------------------------------------------------------------ commands from the app (sound to play)
local function poll_cmd()
    local v = read_json(CMD_FILE)
    if not v or type(v.cmds) ~= "table" then return end
    local top = 0
    for _, c in ipairs(v.cmds) do top = math.max(top, tonumber(c.n) or 0) end
    if last_cmd_n == nil then last_cmd_n = top; return end
    for _, c in ipairs(v.cmds) do
        local n = tonumber(c.n) or 0
        if n > last_cmd_n then
            local from = tostring(c.from)
            if c.k == "ann" and type(c.file) == "string" and cfg.hear_announce then
                local a = ann[from]
                if not a then a = { q = {}, cur = nil, vol = 1 }; ann[from] = a end
                if #a.q < 8 then a.q[#a.q + 1] = c.file end
                a.vol = tonumber(c.vol) or 1
            elseif c.k == "wx" and type(c.vals) == "table" then
                -- real weather from BusVoice: apply it and report back whether the game accepted it
                local okc, r, why = pcall(omsi.weather.set, c.vals)
                local good = okc and r == true
                local reason = ""
                if not okc then reason = tostring(r) elseif r ~= true then reason = tostring(why or "") end
                send_udp({ t = "wxr", ok = good, why = reason, tag = c.tag })
            elseif c.k == "mus" then
                if c.op == "start" and cfg.hear_music then
                    local m = mus[from]
                    if m then stop_sound(m.cur); stop_sound(m.prev) end
                    mus[from] = { gen = tostring(c.gen), idx = 1, dur = tonumber(c.dur) or 4, cur = nil, prev = nil, t = -1000, vol = tonumber(c.vol) or 1 }
                elseif c.op == "stop" then
                    local m = mus[from]
                    if m then stop_sound(m.cur); stop_sound(m.prev); mus[from] = nil end
                end
            end
        end
    end
    if top > last_cmd_n then last_cmd_n = top end
end

local function sound_playing(id)
    if not id then return false end
    local ok, r = pcall(omsi.audio.playing, id)
    return ok and r == true
end

local function update_audio()
    local now = omsi.time()
    for from, a in pairs(ann) do
        local opts, inside, dist = source_opts(from, a.vol)
        if a.cur and sound_playing(a.cur) then
            if opts then pcall(omsi.audio.set, a.cur, opts) else stop_sound(a.cur); a.cur = nil end
        else
            a.cur = nil
            if #a.q > 0 and cfg.hear_announce then
                local f = table.remove(a.q, 1)
                -- an announcement is only for those inside the bus; outside, only when standing right beside it
                if opts and inside then
                    local ok, id = pcall(omsi.audio.play, f, opts)
                    if ok and id then a.cur = id end
                end
            end
        end
    end
    for from, m in pairs(mus) do
        local opts = source_opts(from, m.vol)
        if m.cur and sound_playing(m.cur) then
            if opts then pcall(omsi.audio.set, m.cur, opts) else stop_sound(m.cur); m.cur = nil end
        else
            m.cur = nil
        end
        if m.prev and sound_playing(m.prev) then
            if opts then pcall(omsi.audio.set, m.prev, opts) else stop_sound(m.prev); m.prev = nil end
        else
            m.prev = nil
        end
        if opts and cfg.hear_music and (now - m.t) >= (m.dur - 0.04) then
            -- the newest finished chunk number is kept by the app in a small text file
            local lt = read_text(string.format("m_%s_%s_latest.txt", from, m.gen))
            local latest = tonumber(lt or "")
            if latest and m.idx < latest - 3 then m.idx = latest - 1 end
            local f = string.format("m_%s_%s_%05d.wav", from, m.gen, m.idx)
            local ok, id = pcall(omsi.audio.play, f, opts)
            if ok and id then
                m.prev = m.cur
                m.cur = id
                m.idx = m.idx + 1
                m.t = now
            end
        end
    end
end

-- ------------------------------------------------------------------ events
omsi.on("lan_message", function(from, text)
    if type(text) ~= "string" then return end
    if text:sub(1, 1) == "~" then
        -- audio data of another player's music (Opus packets): passed on to BusVoice as is
        if cfg.hear_music then send_udp({ t = "d", from = tostring(from), d = text:sub(2) }) end
        return
    end
    if text:sub(1, #LAN_PREFIX) ~= LAN_PREFIX then return end
    local p = players[tostring(from)]
    send_udp({ t = "msg", from = tostring(from), name = p and p.name or nil, text = text })
end)

omsi.on("lan_leave", function(id, name)
    stop_player(tostring(id))
    send_udp({ t = "leave", from = tostring(id) })
end)

omsi.on("setting", function(key, value)
    cfg[key] = value
    if key == "hear_announce" or key == "hear_music" then
        if value == false then stop_all() end
    end
    last_hb = -100
end)

omsi.on("start", function()
    omsi.log("BusVoice Net v1 loaded; companion UDP port " .. tostring(PORT))
    heartbeat()
end)

omsi.on("stop", function() stop_all() end)

pcall(omsi.input.hotkey, "Ctrl+Alt+KeyB", function() pcall(omsi.plugin.show_settings) end)

omsi.every(0.05, function()
    pcall(poll_cmd)
    pcall(update_audio)
end)

omsi.every(0.1, function()
    pcall(pump_outbox)
end)

omsi.every(0.25, function()
    pcall(poll_out)
    pcall(refresh_players)
    local now = omsi.time()
    if now - last_hb >= 2.0 then
        last_hb = now
        pcall(heartbeat)
    end
end)
