-- BusVoice Auto — Lua-плагин для openOMSI (этап 1: только телеметрия, см. bvomsilink.py/bvautoeng.py).
-- Шлёт в BusVoice (UDP, 127.0.0.1, как документирует omsi.send) текущие line/tour/trip/next_stop и
-- паузу — этого достаточно, чтобы BusVoice сам решил, какую остановку объявить (bvstopseq.py), и
-- озвучил её штатным root.announce(idx) — то есть тем же путём, что и ручная кнопка/горячая клавиша.
-- Больше этот плагин ничего не делает: ни звука, ни логики остановок — это сознательно на стороне
-- Python (проще менять и тестировать, не привязано к перезапуску игры при каждой правке).

local PORT = 47823
local PERIOD = 0.5

local function send_state()
  local ok, info = pcall(omsi.info)
  if not ok or not info then return end
  omsi.send(PORT, omsi.json.encode({
    type = "game_state",
    line = info.line,
    tour = info.tour,
    trip = info.trip,
    trip_name = info.trip_name,
    next_stop_name = info.next_stop,
    paused = info.paused,
  }))
end

omsi.on("stop_arrive", function() send_state() end)
omsi.on("stop_depart", function() send_state() end)
omsi.every(PERIOD, send_state)

omsi.send(PORT, omsi.json.encode({ type = "plugin_started" }))
omsi.log("BusVoiceAuto: загружен, порт " .. PORT)
