-- BusVoice Auto — Lua-плагин для openOMSI (этап 1: только телеметрия, см. bvomsilink.py/bvautoeng.py).
-- Шлёт в BusVoice (UDP, 127.0.0.1, как документирует omsi.send) текущие line/tour/trip/next_stop и
-- паузу — этого достаточно, чтобы BusVoice сам решил, какую остановку объявить (bvstopseq.py), и
-- озвучил её штатным root.announce(idx) — то есть тем же путём, что и ручная кнопка/горячая клавиша.
-- Также шлёт список остановок текущего рейса прямо из игры (omsi.duty.stops()), чтобы игроку не
-- приходилось вручную выбирать .hof файл карты.
-- Больше этот плагин ничего не делает: ни звука, ни логики остановок — это сознательно на стороне
-- Python (проще менять и тестировать, не привязано к перезапуску игры при каждой правке).

local PORT = 47823
local PERIOD = 0.5

local function send_state()
  local ok, info = pcall(omsi.info)
  if not ok or not info then return end
  omsi.send(PORT, omsi.json.encode({
    type = "game_state",
    line = info.line,
    tour = info.tour,
    trip = info.trip,
    trip_name = info.trip_name,
    next_stop_name = info.next_stop,
    paused = info.paused,
  }))
end

-- Отдельные события на приход/отход — раньше слались только как общее «состояние изменилось»,
-- из-за чего BusVoice объявлял только следующую остановку при отъезде, а приход молчал.
omsi.on("stop_arrive", function(name, id, number, delay)
  omsi.send(PORT, omsi.json.encode({
    type = "stop_event", kind = "arrive", stop_name = name, stop_id = id, number = number,
  }))
end)

omsi.on("stop_depart", function(name, id, number, delay)
  omsi.send(PORT, omsi.json.encode({
    type = "stop_event", kind = "depart", stop_name = name, stop_id = id, number = number,
  }))
end)

-- Список остановок текущего рейса — прямо из самой игры (omsi.duty.stops()), чтобы игроку не
-- приходилось вручную выбирать .hof файл карты: достаточно взять дежурство (выбрать автобус и
-- маршрут) обычным способом в игре, и BusVoice подхватит список остановок сам.
local function send_route()
  local ok, d = pcall(omsi.duty.get)
  if not ok or not d then return end
  local ok2, stops = pcall(omsi.duty.stops)
  if not ok2 or not stops then return end
  local names = {}
  for _, s in ipairs(stops) do
    -- stops=false — автобус проезжает мимо без остановки; closed — закрыта сегодня (объезд).
    -- Такие в список для объявления не включаем.
    if s.stops ~= false and not s.closed then
      names[#names + 1] = s.name
    end
  end
  local ok3, map_name = pcall(omsi.map.name)
  omsi.send(PORT, omsi.json.encode({
    type = "route_stops",
    map = ok3 and map_name or nil,
    line = d.line,
    tour = d.tour,
    trip = d.trip,
    trip_name = d.trip_name,
    stops = names,
  }))
end

omsi.on("duty_start", function(line, tour) send_route() end)
omsi.on("trip_start", function(trip, name, terminus) send_route() end)
-- если дежурство уже было взято до того, как плагин загрузился
send_route()

omsi.every(PERIOD, send_state)
omsi.every(5, send_route)

omsi.send(PORT, omsi.json.encode({ type = "plugin_started" }))
omsi.log("BusVoiceAuto: загружен, порт " .. PORT)
