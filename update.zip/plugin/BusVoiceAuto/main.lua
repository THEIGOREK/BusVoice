-- BusVoice Auto — Lua-плагин для openOMSI (этап 1: только телеметрия, см. bvomsilink.py/bvautoeng.py).
-- Шлёт в BusVoice (UDP, 127.0.0.1, как документирует omsi.send) текущие line/tour/trip/next_stop и
-- паузу — этого достаточно, чтобы BusVoice сам решил, какую остановку объявить (bvstopseq.py), и
-- озвучил её штатным root.announce(idx) — то есть тем же путём, что и ручная кнопка/горячая клавиша.
-- Также шлёт список остановок текущего рейса прямо из игры (omsi.duty.stops()), чтобы игроку не
-- приходилось вручную выбирать .hof файл карты.
-- Больше этот плагин ничего не делает: ни звука, ни логики остановок — это сознательно на стороне
-- Python (проще менять и тестировать, не привязано к перезапуску игры при каждой правке).

local PORT = 47823
local PERIOD = 0.5

-- Best-effort поиск переменной скрипта автобуса (.osc) под двери/окна — см. подробное объяснение
-- внутри send_state ниже. Сканируем omsi.vars() только один раз на автобус (кэш), не на каждый
-- тик (0.5 с) — omsi.vars() может вернуть сотни имён, незачем перебирать их постоянно.
local _bv_var_scanned = false
local _bv_door_var, _bv_window_var = nil, nil

local function _bv_scan_vars()
  if _bv_var_scanned then return end
  _bv_var_scanned = true
  local ok, names = pcall(omsi.vars)
  if not ok or type(names) ~= "table" then return end
  for _, name in ipairs(names) do
    local ok2, lname = pcall(string.lower, name)
    if ok2 then
      if not _bv_door_var and string.find(lname, "door") then
        _bv_door_var = name
      end
      if not _bv_window_var and (string.find(lname, "window") or string.find(lname, "fenster")) then
        _bv_window_var = name
      end
    end
  end
end

function _bv_door_state()
  _bv_scan_vars()
  if not _bv_door_var then return true end
  local ok, v = pcall(omsi.var, _bv_door_var)
  if not ok or v == nil then return true end
  return (tonumber(v) or 1) ~= 0
end

function _bv_window_state()
  _bv_scan_vars()
  if not _bv_window_var then return true end
  local ok, v = pcall(omsi.var, _bv_window_var)
  if not ok or v == nil then return true end
  return (tonumber(v) or 1) ~= 0
end

-- При смене автобуса (документированное событие "vehicle") старый найденный номер переменной
-- уже не годится — сбрасываем кэш, чтобы пересканировать заново для нового автобуса.
pcall(function()
  omsi.on("vehicle", function()
    _bv_var_scanned = false
    _bv_door_var, _bv_window_var = nil, nil
  end)
end)

local function send_state()
  local ok, info = pcall(omsi.info)
  if not ok or not info then return end
  -- in_cab: камера в своём автобусе (водитель/пассажир) или снаружи (outside/free/foot) —
  -- нужно BusVoice, чтобы приглушать свою музыку/информатор, когда их "не должно быть слышно"
  -- (фаза 2, см. bvautoeng.py/bvfix.py).
  -- ВАЖНО: тут нельзя писать `(ok2 and in_cab ~= nil) and in_cab or true` — в Lua идиома
  -- `X and Y or Z` ломается, когда Y сам по себе ложный: если in_cab и правда false (камера
  -- снаружи), `X and false` уже ложно, и выражение проваливается в `or true`, так что поле
  -- всегда получалось true, даже снаружи. Пишем через явный if, без ловушки and/or.
  local ok2, in_cab_v = pcall(omsi.camera.in_cab)
  local in_cab_out = true
  if ok2 and in_cab_v ~= nil then
    in_cab_out = in_cab_v
  end
  -- doors_open/windows_open: своего автобуса — нужно BusVoice для "3D"-приглушения снаружи
  -- (фаза 2, часть 3): если и двери, и окна закрыты, музыку снаружи почти не слышно (глухой
  -- бас через стенки), если хоть что-то открыто — немного слышнее.
  --
  -- НАЙДЕНО (реальный краш у пользователя, "attempt to index a function value (field
  -- 'vehicle')"): omsi.vehicle.doors_open/omsi.vehicle.windows_open — это была ОШИБКА в самом
  -- коде, не опечатка в игре. По официальной документации openOMSI (openOMSI-org/openOMSI,
  -- docs/PLUGINS.md) omsi.vehicle — это ФУНКЦИЯ (возвращает название автобуса), а не таблица с
  -- полями, поэтому `omsi.vehicle.doors_open` падал ещё ДО вызова pcall (сама ошибка — при
  -- вычислении аргумента pcall, то есть вне его защиты), и это останавливало ВЕСЬ плагин
  -- целиком (включая обычные объявления остановок, не только приглушение).
  --
  -- Честно: готового документированного способа узнать "открыты ли двери/окна" у openOMSI нет —
  -- официально есть только omsi.var(имя), читающий переменную скрипта автобуса (как в .osc), а
  -- единого имени переменной для дверей/окон на ВСЕХ автобусах нет (у каждой модели свои). Ищем
  -- best-effort: один раз на автобус (и заново при смене автобуса) перебираем все переменные
  -- через omsi.vars() и берём первую, где в названии есть "door"/"window"/"fenster". Если такой
  -- переменной нет или сам omsi.vars()/omsi.var() не существует в этой версии игры — считаем
  -- двери/окна открытыми (безопасное значение по умолчанию, равнозначное «без 3D-приглушения» —
  -- так было и до этой функции, хуже не станет). Вся эта логика — целиком внутри pcall(function()
  -- ... end), а не pcall(omsi.X.Y), чтобы ни индексирование, ни сам вызов не могли уронить плагин.
  local ok3, doors_out = pcall(function() return _bv_door_state() end)
  if not ok3 or doors_out == nil then doors_out = true end
  local ok4, windows_out = pcall(function() return _bv_window_state() end)
  if not ok4 or windows_out == nil then windows_out = true end
  omsi.send(PORT, omsi.json.encode({
    type = "game_state",
    line = info.line,
    tour = info.tour,
    trip = info.trip,
    trip_name = info.trip_name,
    next_stop_name = info.next_stop,
    paused = info.paused,
    in_cab = in_cab_out,
    doors_open = doors_out,
    windows_open = windows_out,
  }))
end

-- Отдельные события на приход/отход — раньше слались только как общее «состояние изменилось»,
-- из-за чего BusVoice объявлял только следующую остановку при отъезде, а приход молчал.
omsi.on("stop_arrive", function(name, id, number, delay)
  omsi.send(PORT, omsi.json.encode({
    type = "stop_event", kind = "arrive", stop_name = name, stop_id = id, number = number,
  }))
end)

omsi.on("stop_depart", function(name, id, number, delay)
  omsi.send(PORT, omsi.json.encode({
    type = "stop_event", kind = "depart", stop_name = name, stop_id = id, number = number,
  }))
end)

-- Список остановок текущего рейса — прямо из самой игры (omsi.duty.stops()), чтобы игроку не
-- приходилось вручную выбирать .hof файл карты: достаточно взять дежурство (выбрать автобус и
-- маршрут) обычным способом в игре, и BusVoice подхватит список остановок сам.
local function send_route()
  local ok, d = pcall(omsi.duty.get)
  if not ok or not d then return end
  local ok2, stops = pcall(omsi.duty.stops)
  if not ok2 or not stops then return end
  local names = {}
  for _, s in ipairs(stops) do
    -- stops=false — автобус проезжает мимо без остановки; closed — закрыта сегодня (объезд).
    -- Такие в список для объявления не включаем.
    if s.stops ~= false and not s.closed then
      names[#names + 1] = s.name
    end
  end
  local ok3, map_name = pcall(omsi.map.name)
  omsi.send(PORT, omsi.json.encode({
    type = "route_stops",
    map = ok3 and map_name or nil,
    line = d.line,
    tour = d.tour,
    trip = d.trip,
    trip_name = d.trip_name,
    stops = names,
  }))
end

omsi.on("duty_start", function(line, tour) send_route() end)
omsi.on("trip_start", function(trip, name, terminus) send_route() end)
-- если дежурство уже было взято до того, как плагин загрузился
send_route()

omsi.every(PERIOD, send_state)
omsi.every(5, send_route)

omsi.send(PORT, omsi.json.encode({ type = "plugin_started" }))
omsi.log("BusVoiceAuto: загружен, порт " .. PORT)
