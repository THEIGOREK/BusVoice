# -*- coding: utf-8 -*-
"""Установщик BusVoice (окно). Обычный Python-скрипт: его можно прочитать целиком."""
import os
import shutil
import subprocess
import sys
import queue
import threading
import tkinter as tk
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "BusVoice"
TEST = bool(os.environ.get("BV_SETUP_TEST"))
BG, PANEL, PANEL2, ACC, ACC2, TXT, MUT, OK, ERR = "#0e1220", "#161b2e", "#1e2540", "#17a398", "#0f7d74", "#eef2f8", "#8b94ab", "#4cd964", "#ff6b6b"

L = {
    "ru": ("Русский", "Установка BusVoice", "Автоинформатор для openOMSI", "Папка установки", "Обзор…", "Создать ярлык на рабочем столе",
           "Запустить BusVoice после установки", "Установить", "Далее", "Готово", "Закрыть", "Копирую файлы…", "Ставлю библиотеки Python (1–3 мин, нужен интернет)…",
           "Создаю ярлык…", "✅ BusVoice установлен", "❌ Ошибка установки", "Язык / Language", "Не удалось установить библиотеки Python. Проверьте интернет и повторите."),
    "en": ("English", "BusVoice setup", "Stop announcer for openOMSI", "Install folder", "Browse…", "Create a desktop shortcut",
           "Launch BusVoice when finished", "Install", "Next", "Done", "Close", "Copying files…", "Installing Python libraries (1–3 min, internet required)…",
           "Creating shortcut…", "✅ BusVoice is installed", "❌ Installation error", "Language", "Could not install Python libraries. Check the internet and retry."),
    "uk": ("Українська", "Встановлення BusVoice", "Автоінформатор для openOMSI", "Папка встановлення", "Огляд…", "Створити ярлик на робочому столі",
           "Запустити BusVoice після встановлення", "Встановити", "Далі", "Готово", "Закрити", "Копіюю файли…", "Встановлюю бібліотеки Python (1–3 хв, потрібен інтернет)…",
           "Створюю ярлик…", "✅ BusVoice встановлено", "❌ Помилка встановлення", "Мова / Language", "Не вдалося встановити бібліотеки Python. Перевірте інтернет і повторіть."),
    "be": ("Беларуская", "Усталяванне BusVoice", "Аўтаінфарматар для openOMSI", "Папка ўсталявання", "Агляд…", "Стварыць ярлык на працоўным стале",
           "Запусціць BusVoice пасля ўсталявання", "Усталяваць", "Далей", "Гатова", "Закрыць", "Капіюю файлы…", "Усталёўваю бібліятэкі Python (1–3 хв, патрэбны інтэрнэт)…",
           "Ствараю ярлык…", "✅ BusVoice усталяваны", "❌ Памылка ўсталявання", "Мова / Language", "Не атрымалася ўсталяваць бібліятэкі Python. Праверце інтэрнэт і паўтарыце."),
    "kk": ("Қазақша", "BusVoice орнату", "openOMSI үшін аялдама хабарлаушысы", "Орнату қалтасы", "Шолу…", "Жұмыс үстеліне белгіше жасау",
           "Орнатқаннан кейін BusVoice іске қосу", "Орнату", "Әрі қарай", "Дайын", "Жабу", "Файлдар көшірілуде…", "Python кітапханалары орнатылуда (1–3 мин, интернет керек)…",
           "Белгіше жасалуда…", "✅ BusVoice орнатылды", "❌ Орнату қатесі", "Тіл / Language", "Python кітапханаларын орнату мүмкін болмады. Интернетті тексеріп, қайталаңыз."),
}
(I_NAME, I_TITLE, I_SUB, I_DIR, I_BROWSE, I_DESK, I_RUN, I_INSTALL, I_NEXT, I_DONE, I_CLOSE, I_COPY, I_PIP, I_LNK, I_OK, I_ERR, I_LANG, I_PIPFAIL) = range(18)


def default_dir():
    return os.path.join(os.environ.get("LOCALAPPDATA") or str(Path.home()), "BusVoice")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BusVoice")
        self.configure(bg=BG)
        self.geometry("620x440")
        self.resizable(False, False)
        self.lang = "ru"
        self.dir = tk.StringVar(value=default_dir())
        self.desk = tk.BooleanVar(value=True)
        self.run = tk.BooleanVar(value=True)
        try:
            ico = SRC / "icon.ico"
            if ico.exists() and os.name == "nt":
                self.iconbitmap(str(ico))
        except Exception:
            pass
        self.q = queue.Queue()
        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill="both", expand=True)
        self.page_lang()
        self.after(80, self.pump)

    def pump(self):
        """Сообщения из потока установки выполняются в главном потоке окна."""
        try:
            while True:
                self.q.get_nowait()()
        except queue.Empty:
            pass
        except Exception:
            pass
        self.after(80, self.pump)

    # ---- общие куски
    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def header(self, sub=None):
        h = tk.Frame(self.body, bg=PANEL)
        h.pack(fill="x")
        c = tk.Canvas(h, width=54, height=54, bg=PANEL, highlightthickness=0)
        c.pack(side="left", padx=(24, 12), pady=14)
        c.create_oval(2, 2, 52, 52, fill=ACC, outline="")
        c.create_text(27, 27, text="🚌", font=("Segoe UI Emoji", 20), fill="#ffffff")
        t = tk.Frame(h, bg=PANEL)
        t.pack(side="left")
        tk.Label(t, text="BusVoice", bg=PANEL, fg=TXT, font=("Segoe UI", 20, "bold")).pack(anchor="w")
        tk.Label(t, text=sub or L[self.lang][I_SUB], bg=PANEL, fg=MUT, font=("Segoe UI", 11)).pack(anchor="w")
        tk.Frame(self.body, bg=ACC, height=3).pack(fill="x")

    def button(self, parent, text, cmd, primary=True, width=16):
        b = tk.Button(parent, text=text, command=cmd, bg=ACC if primary else PANEL2, fg="#ffffff", activebackground=ACC2 if primary else "#2a3358",
                      activeforeground="#ffffff", relief="flat", bd=0, font=("Segoe UI", 11, "bold"), width=width, pady=7, cursor="hand2")
        return b

    # ---- страница 1: язык
    def page_lang(self):
        self.clear()
        self.header()
        tk.Label(self.body, text=L[self.lang][I_LANG], bg=BG, fg=TXT, font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=30, pady=(22, 10))
        row = tk.Frame(self.body, bg=BG)
        row.pack(anchor="w", padx=30)
        self.lang_btns = {}
        for i, (k, v) in enumerate(L.items()):
            b = tk.Button(row, text=v[I_NAME], command=lambda k=k: self.set_lang(k), relief="flat", bd=0, font=("Segoe UI", 11), width=14, pady=8, cursor="hand2",
                          fg="#ffffff")
            b.grid(row=i // 3, column=i % 3, padx=5, pady=5)
            self.lang_btns[k] = b
        self.mark_lang()
        foot = tk.Frame(self.body, bg=BG)
        foot.pack(side="bottom", fill="x", padx=30, pady=22)
        self.nextb = self.button(foot, L[self.lang][I_NEXT] + "  ▸", self.page_opts)
        self.nextb.pack(side="right")

    def mark_lang(self):
        for k, b in self.lang_btns.items():
            b.configure(bg=ACC if k == self.lang else PANEL2, activebackground=ACC2)

    def set_lang(self, k):
        self.lang = k
        self.page_lang()

    # ---- страница 2: папка и галочки
    def page_opts(self):
        self.clear()
        self.header()
        t = L[self.lang]
        tk.Label(self.body, text=t[I_DIR], bg=BG, fg=TXT, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=30, pady=(22, 6))
        r = tk.Frame(self.body, bg=BG)
        r.pack(fill="x", padx=30)
        tk.Entry(r, textvariable=self.dir, bg=PANEL, fg=TXT, insertbackground=TXT, relief="flat", font=("Segoe UI", 11)).pack(side="left", fill="x", expand=True, ipady=7)
        self.button(r, t[I_BROWSE], self.browse, False, 10).pack(side="left", padx=(8, 0))
        for var, txt in ((self.desk, t[I_DESK]), (self.run, t[I_RUN])):
            tk.Checkbutton(self.body, text=txt, variable=var, bg=BG, fg=TXT, selectcolor=PANEL2, activebackground=BG, activeforeground=TXT,
                           font=("Segoe UI", 11)).pack(anchor="w", padx=26, pady=(14, 0))
        foot = tk.Frame(self.body, bg=BG)
        foot.pack(side="bottom", fill="x", padx=30, pady=22)
        self.button(foot, t[I_INSTALL], self.install).pack(side="right")

    def browse(self):
        from tkinter import filedialog
        d = filedialog.askdirectory(initialdir=self.dir.get() or default_dir())
        if d:
            self.dir.set(str(Path(d) / "BusVoice") if Path(d).name.lower() != "busvoice" else d)

    # ---- страница 3: установка
    def install(self):
        self.target = Path(self.dir.get().strip() or default_dir())
        self.clear()
        self.header()
        t = L[self.lang]
        self.status = tk.Label(self.body, text="", bg=BG, fg=TXT, font=("Segoe UI", 12), wraplength=560, justify="left")
        self.status.pack(anchor="w", padx=30, pady=(26, 8))
        self.bar = tk.Canvas(self.body, width=560, height=10, bg=PANEL2, highlightthickness=0)
        self.bar.pack(padx=30, anchor="w")
        self.fill = self.bar.create_rectangle(0, 0, 0, 10, fill=ACC, outline="")
        self.log = tk.Label(self.body, text="", bg=BG, fg=MUT, font=("Consolas", 9), wraplength=560, justify="left", anchor="w")
        self.log.pack(anchor="w", padx=30, pady=10, fill="x")
        self.foot = tk.Frame(self.body, bg=BG)
        self.foot.pack(side="bottom", fill="x", padx=30, pady=22)
        threading.Thread(target=self.work, daemon=True).start()

    def ui(self, text=None, pct=None, log=None):
        def f():
            if text is not None:
                self.status.configure(text=text, fg=TXT)
            if pct is not None:
                self.bar.coords(self.fill, 0, 0, 560 * pct / 100.0, 10)
            if log is not None:
                self.log.configure(text=log[-160:])
        self.q.put(f)

    def finish(self, ok, msg):
        def f():
            self.status.configure(text=msg, fg=OK if ok else ERR)
            self.button(self.foot, L[self.lang][I_DONE if ok else I_CLOSE], self.done if ok else self.destroy).pack(side="right")
        self.q.put(f)

    def done(self):
        if self.run.get() and not TEST:
            try:
                pw = self.pythonw()
                subprocess.Popen([pw, str(self.target / "busvoice.py")], cwd=str(self.target))
            except Exception:
                pass
        self.destroy()

    def pythonw(self):
        d = os.path.dirname(sys.executable)
        p = os.path.join(d, "pythonw.exe")
        return p if os.path.exists(p) else sys.executable

    def work(self):
        t = L[self.lang]
        try:
            self.ui(t[I_COPY], 10)
            if not (SRC / "busvoice.py").exists():
                raise RuntimeError("BusVoice/busvoice.py not found next to the installer")
            shutil.copytree(SRC, self.target, dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__"))
            self.ui(t[I_PIP], 35)
            if not TEST:
                flags = 0x08000000 if os.name == "nt" else 0
                p = subprocess.Popen([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(self.target / "requirements.txt")],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", creationflags=flags)
                n = 0
                for line in p.stdout:
                    n += 1
                    self.ui(None, min(85, 35 + n * 1.2), line.strip())
                if p.wait() != 0:
                    raise RuntimeError(t[I_PIPFAIL])
            self.ui(t[I_LNK], 90)
            if self.desk.get() and os.name == "nt" and not TEST:
                ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\\BusVoice.lnk');"
                      "$s.TargetPath='%s';$s.Arguments='\"%s\"';$s.WorkingDirectory='%s';$s.IconLocation='%s';$s.Save()"
                      % (self.pythonw(), self.target / "busvoice.py", self.target, self.target / "icon.ico"))
                subprocess.run(["powershell", "-NoProfile", "-Command", ps], creationflags=0x08000000, timeout=60)
            self.ui(None, 100, str(self.target))
            self.finish(True, t[I_OK])
        except Exception as e:
            self.finish(False, t[I_ERR] + ": " + str(e))


if __name__ == "__main__":
    App().mainloop()
