@echo off
chcp 65001 >nul
title Установка BusVoice
setlocal
echo.
echo  === Установка BusVoice ===
echo  Это обычный текстовый скрипт: его можно открыть в Блокноте и прочитать.
echo  Он находит Python ^(или ставит его через winget^) и открывает окно установщика.
echo.
if not exist "%~dp0BusVoice\busvoice.py" (
  echo  Сначала распакуйте архив целиком, затем запустите этот файл снова.
  pause
  exit /b 1
)

set "PY="
call :findpy
if not defined PY (
  echo  Python не найден. Пробую установить Python 3.12 через winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  call :findpy
)
if not defined PY (
  echo.
  echo  Не удалось найти Python. Установите его вручную с https://www.python.org/downloads/
  echo  ^(отметьте галочку Add python.exe to PATH^) и запустите этот файл снова.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)

set "PYW="
for /f "delims=" %%I in ('%PY% -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do set "PYW=%%I"
if not exist "%PYW%" set "PYW=pythonw"
start "" "%PYW%" "%~dp0setup_gui.pyw"
exit /b 0

:findpy
where py >nul 2>&1 && py -3 -c "import sys" >nul 2>&1 && set "PY=py -3" && goto :eof
python -c "import sys" >nul 2>&1 && set "PY=python" && goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
goto :eof
