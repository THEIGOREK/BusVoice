@echo off
chcp 65001 >nul
title Установка BusVoice
setlocal
set "SRC=%~dp0BusVoice"
set "DST=%LOCALAPPDATA%\BusVoice"
echo.
echo  === Установка BusVoice ===
echo  Это обычный текстовый скрипт: его можно открыть в Блокноте и прочитать.
echo  Он копирует файлы в %DST%, ставит библиотеки Python и создаёт ярлык.
echo.
if not exist "%SRC%\busvoice.py" (
  echo  Сначала распакуйте архив целиком, затем запустите этот файл снова.
  pause
  exit /b 1
)

set "PY="
call :findpy
if not defined PY (
  echo  Python не найден. Пробую установить Python 3.12 через winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  call :findpy
)
if not defined PY (
  echo.
  echo  Не удалось найти Python. Установите его вручную с https://www.python.org/downloads/
  echo  ^(отметьте галочку Add python.exe to PATH^) и запустите этот файл снова.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)

echo  Копирую файлы...
xcopy "%SRC%\*" "%DST%\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo  Не удалось скопировать файлы в %DST%
  pause
  exit /b 1
)

echo  Ставлю библиотеки Python ^(1-3 минуты, нужен интернет^)...
%PY% -m pip install --disable-pip-version-check -r "%DST%\requirements.txt"
if errorlevel 1 (
  echo.
  echo  Не удалось поставить библиотеки. Проверьте интернет и запустите файл снова.
  pause
  exit /b 1
)

set "PYW="
for /f "delims=" %%I in ('%PY% -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do set "PYW=%%I"
if not exist "%PYW%" set "PYW=pythonw"

echo  Создаю ярлык на рабочем столе...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\BusVoice.lnk');$s.TargetPath='%PYW%';$s.Arguments='\"%DST%\busvoice.py\"';$s.WorkingDirectory='%DST%';$s.IconLocation='%DST%\icon.ico';$s.Save()"

echo.
echo  Готово! Запускаю BusVoice...
start "" "%PYW%" "%DST%\busvoice.py"
timeout /t 3 >nul
exit /b 0

:findpy
where py >nul 2>&1 && py -3 -c "import sys" >nul 2>&1 && set "PY=py -3" && goto :eof
python -c "import sys" >nul 2>&1 && set "PY=python" && goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
goto :eof
